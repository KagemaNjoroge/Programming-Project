from etims_vscu_wrapper.clients.http_client import HttpClientInterface

class PurchaseInformation:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id):
        self.api_request = http_client
        self.tin = tin
        self.bhf_id = bhf_id

    def get_purchase_transaction_information(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/trnsPurchase/selectTrnsPurchaseSales', data=request_data)
        return response

    def send_purchase_transaction_confirmation(self, purchase_info):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            **purchase_info
        }
        response = self.api_request.send_request(
            '/trnsPurchase/savePurchases', data=request_data)
        return response
