from etims_vscu_wrapper.clients.http_client import HttpClientInterface

class DataInitialization:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id, device_serial_no):
        self.api_request = http_client
        self.tin = tin
        self.bhf_id = bhf_id
        self.device_serial_no = device_serial_no

    def initialize(self):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "dvcSrlNo": self.device_serial_no
        }
        response = self.api_request.send_request(
            '/initializer/selectInitInfo', data=request_data)
        return response