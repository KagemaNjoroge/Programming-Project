from etims_vscu_wrapper.clients.http_client import HttpClientInterface


class CodeData:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id):
        self.api_request = http_client
        self.tin = tin
        self.bhf_id = bhf_id

    def get_code_list(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/code/selectCodes', data=request_data)
        return response

    def get_item_classification_list(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/itemClass/selectItemsClass', data=request_data)
        return response

    def get_pin_list(self, custmTin):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "custmTin": custmTin
        }
        response = self.api_request.send_request(
            '/customers/selectCustomer', data=request_data)
        return response

    def get_branch_list(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/branches/selectBranches', data=request_data)
        return response

    def get_notice_list(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/notices/selectNotices', data=request_data)
        return response
