from etims_vscu_wrapper.clients.http_client import HttpClientInterface

class StockInformation:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id):
        self.api_request = http_client
        self.tin = tin
        self.bhf_id = bhf_id

    def send_stock_in_out_information(self, stock_io_info):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            **stock_io_info
        }
        response = self.api_request.send_request(
            '/saveStockItems/saveStockItems', data=request_data)
        return response

    def send_stock_inventory_information(self, stock_inventory_info):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            **stock_inventory_info
        }
        response = self.api_request.send_request(
            '/stockMaster/saveStockMaster', data=request_data)
        return response

    def get_stock_movement_list(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/stock/selectStockItems', data=request_data)
        return response
