from etims_vscu_wrapper.clients.http_client import HttpClientInterface

class ItemInformation:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id):
        self.api_request = http_client
        self.tin = tin
        self.bhf_id = bhf_id

    def send_item_information(self, item_info):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            **item_info
        }
        response = self.api_request.send_request(
            '/items/saveItems', data=request_data)
        return response

    def send_item_composition_information(self, composition_info):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            **composition_info
        }
        response = self.api_request.send_request(
            '/items/saveItemComposition', data=request_data)
        return response

    def get_item_list(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/items/selectItems', data=request_data)
        return response
