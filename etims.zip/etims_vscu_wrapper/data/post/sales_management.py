from etims_vscu_wrapper.utils.validate_fields import validate_fields
from dataclasses import dataclass, field
from typing import Optional, List
import logging

@dataclass
class Receipt:
    custTin: str
    rptNo: int
    trdeNm: str
    adrs: str
    topMsg: str
    btmMsg: str
    prchrAcptcYn: str
    custMblNo: Optional[str] = None

    def is_valid(self) -> bool:
        expected_lengths = {
            'custTin': 11,
            'rptNo': 38,
            'trdeNm': 20,
            'adrs': 200,
            'topMsg': 20,
            'btmMsg': 20,
            'prchrAcptcYn': 1,
            'custMblNo': 20
        }
        return validate_fields(expected_lengths, self)
    

@dataclass
class Item:
    itemSeq: int
    itemCd: str
    itemClsCd: str
    itemNm: str
    pkgUnitCd: str
    pkg: int
    qtyUnitCd: str
    qty: int
    prc: int
    splyAmt: int
    dcRt: int
    dcAmt: int
    taxTyCd: str
    taxblAmt: int
    taxAmt: int
    totAmt: int
    bcd: Optional[str] = None
    isrccCd: Optional[str] = None
    isrccNm: Optional[str] = None
    isrcRt: Optional[int] = None
    isrcAmt: Optional[int] = None


    def is_valid(self) -> bool:
        expected_lengths = {
            'itemSeq': 3,
            'itemCd': 20,
            'itemClsCd': 20,
            'itemNm': 200,
            'pkgUnitCd': 5,
            'pkg': 13,
            'qtyUnitCd': 5,
            'qty': 13,
            'prc': 18,
            'splyAmt': 18,
            'dcRt': 5,
            'dcAmt': 18,
            'taxTyCd': 5,
            'taxblAmt': 18,
            'taxAmt': 18,
            'totAmt': 18,
            'bcd': 20,
            'isrccCd': 10,
            'isrccNm': 100,
            'isrcRt': 3,
            'isrcAmt': 18
        }
        return validate_fields(expected_lengths, self)

@dataclass
class SalesTransaction:
    trdInvcNo: int
    invcNo: int
    orgInvcNo: int
    custTin: str
    custNm: str
    salesTyCd: str
    rcptTyCd: str
    pmtTyCd: str
    salesSttsCd: str
    cfmDt: str
    salesDt: str
    stockRlsDt: str
    totItemCnt: int
    taxblAmtA: int
    taxblAmtB: int
    taxblAmtC: int
    taxblAmtD: int
    taxblAmtE: int
    taxRtA: int
    taxRtB: int
    taxRtC: int
    taxRtD: int
    taxRtE: int
    taxAmtA: int
    taxAmtB: int
    taxAmtC: int
    taxAmtD: int
    taxAmtE: int
    totTaxblAmt: int
    totTaxAmt: int
    totAmt: int
    prchrAcptcYn: str
    regrId: str
    regrNm: str
    modrId: str
    modrNm: str
    receipt: Receipt
    itemList: List[Item]
    cnclReqDt: Optional[str] = None
    cnclDt: Optional[str] = None
    rfdDt: Optional[str] = None
    rfdRsnCd: Optional[str] = None
    remark: Optional[str] = None

    def is_valid(self) -> bool:
        expected_lengths = {
            'trdInvcNo': 50,
            'invcNo': 38,
            'orgInvcNo': 38,
            'custTin': 11,
            'custNm': 60,
            'salesTyCd': 5,
            'rcptTyCd': 5,
            'pmtTyCd': 5,
            'salesSttsCd': 5,
            'cfmDt': 14,
            'salesDt': 8,
            'stockRlsDt': 14,
            'totItemCnt': 10,
            'taxblAmtA': 18,
            'taxblAmtB': 18,
            'taxblAmtC': 18,
            'taxblAmtD': 18,
            'taxblAmtE': 18,
            'taxRtA': 7,
            'taxRtB': 7,
            'taxRtC': 7,
            'taxRtD': 7,
            'taxRtE': 7,
            'taxAmtA': 18,
            'taxAmtB': 18,
            'taxAmtC': 18,
            'taxAmtD': 18,
            'taxAmtE': 18,
            'totTaxblAmt': 18,
            'totTaxAmt': 18,
            'totAmt': 18,
            'prchrAcptcYn': 1,
            'regrId': 20,
            'regrNm': 60,
            'modrId': 20,
            'modrNm': 60,
            'cnclReqDt': 14,
            'cnclDt': 14,
            'rfdDt': 14,
            'rfdRsnCd': 5,
            'remark': 400
        }
        return validate_fields(expected_lengths, self)