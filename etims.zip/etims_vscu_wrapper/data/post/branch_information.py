from dataclasses import dataclass
from typing import Optional
import logging

from etims_vscu_wrapper.utils.validate_fields import validate_fields

# Set up logging configuration
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class CustomerInformation:
    custNo: str
    custTin: str
    custNm: str
    regrNm: str
    regrId: str
    modrNm: str
    modrId: str
    useYn: str = 'Y'
    adrs: Optional[str] = None
    telNo: Optional[str] = None
    email: Optional[str] = None
    faxNo: Optional[str] = None
    remark: Optional[str] = None

    def is_valid(self) -> bool:
        # Define expected data lengths
        expected_lengths = {
            "custNo": 9,
            "custTin": 11,
            "custNm": 60,
            "adrs": 300,
            "telNo": 20,
            "email": 50,
            "faxNo": 20,
            "useYn": 1,
            "remark": 1000,
            "regrNm": 60,
            "regrId": 20,
            "modrNm": 60,
            "modrId": 20
        }
        return validate_fields(expected_lengths, self)

@dataclass
class BranchUserAccount:
    userId: str
    userNm: str
    pwd: str
    regrNm: str
    regrId: str
    modrNm: str
    modrId: str
    useYn: str = 'Y'
    adrs: Optional[str] = None
    cntc: Optional[str] = None
    authCd: Optional[str] = None
    remark: Optional[str] = None

    def is_valid(self) -> bool:
        # Define expected data lengths
        expected_lengths = {
            "userId": 20,
            "userNm": 60,
            "pwd": 255,
            "adrs": 200,
            "cntc": 20,
            "authCd": 100,
            "remark": 2000,
            "useYn": 1,
            "regrNm": 60,
            "regrId": 20,
            "modrNm": 60,
            "modrId": 20
        }
        return validate_fields(expected_lengths, self)


@dataclass
class BranchInsuranceInformation:
    isrccCd: str
    isrccNm: str
    isrcRt: int
    useYn: str = 'Y'
    regrNm: str = 'Admin'
    regrId: str = 'Admin'
    modrNm: str = 'Admin'
    modrId: str = 'Admin'

    def is_valid(self) -> bool:
        # Define expected data lengths
        expected_lengths = {
            "tin": 11,
            "bhfId": 2,
            "isrccCd": 10,
            "isrccNm": 100,
            "isrcRt": 3,
            "useYn": 1,
            "regrNm": 60,
            "regrId": 20,
            "modrNm": 60,
            "modrId": 20
        }
        return validate_fields(expected_lengths, self)