# How to Use ETIMS VSCU Wrapper

This document provides instructions on how to use the ETIMS VSCU (Virtual Sales and Collection Unit) Wrapper for integrating with the ETIMS system. The wrapper facilitates communication with the ETIMS backend through HTTP requests.

## Prerequisites

Before using the ETIMS VSCU Wrapper, ensure you have the following:

- Access to the ETIMS system.
- Python installed on your machine.
- Required permissions and credentials to access the ETIMS API.

## Installation

To use the ETIMS VSCU Wrapper, follow these steps:

1. Clone the repository containing the wrapper code.

## Installation

You can install the **ETIMS VSCU Wrapper** package using pip. Navigate to the directory containing `setup.py` and run:

```bash
pip install requests
```

```bash
pip install .
```

## Usage for

### 1. Import Required Modules

```python
from etims_vscu_wrapper.clients.http_client import HttpClient
from etims_vscu_wrapper.core.VSCUProtocol.data_initialization import DataInitialization
from etims_vscu_wrapper.core.VSCUProtocol.branch_information import BranchInformation
from etims_vscu_wrapper.core.VSCUProtocol.code_data import CodeData
from etims_vscu_wrapper.core.VSCUProtocol.item_information import ItemInformation
from etims_vscu_wrapper.core.VSCUProtocol.sales_management import SalesManagement
from etims_vscu_wrapper.data.post.branch_information import CustomerInformation, BranchUserAccount, BranchInsuranceInformation
from etims_vscu_wrapper.data.post.sales_management import Receipt, Item, SalesTransaction
```

### 2. Set Base URL and Parameters

Define the base URL of the ETIMS API and other required parameters:

```python
base_url = 'http://localhost:8088'
# base_url = 'https://quicksalespos.com/'
tin = 'P051238105V'
bhf_id = '07'
device_serial_no = 'DJV007'
```

### 3. Create HTTP Client Instance

Create an instance of the `HttpClient` class with the base URL:

```python
http_client = HttpClient(base_url)
```

### 4. Initialize Data

To initialize data, create an instance of the `DataInitialization` class and call the `initialize()` method:

```python
data_init = DataInitialization(http_client, tin, bhf_id, device_serial_no)
device_init_response = data_init.initialize()
```

### 5. Access Code Data

You can access various code data by instantiating the `CodeData` class:

```python
code_data = CodeData(http_client, tin, bhf_id)

# Example: Get code list
code_list_response = code_data.get_code_list()
# Example: Get item classification list
item_classification_response = code_data.get_item_classification_list()
# Example: Get pin list
pin_list_response = code_data.get_pin_list("P051238105V")
# Example: Get branch list
branch_list_response = code_data.get_branch_list()
# Example: Get notice list
notice_list_response = code_data.get_notice_list()
```

### 6. Branch Information

You can interact with branch information using the `BranchInformation` class:

```python
branch_info = BranchInformation(http_client, tin, bhf_id)

customer_info = CustomerInformation(
    custNo="999991113",
    custTin="A123456789Z",
    custNm="MTEJA LIMITED",
    regrNm="Admin",
    regrId="Admin",
    modrNm="Admin",
    modrId="Admin"
)

# Example: Send customer information
customer_info_response = branch_info.send_customer_information(customer_info)

branch_user_account_info = BranchUserAccount(
    userId="userId3",
    userNm="UserName3",
    pwd="12341234",
    regrNm="Admin",
    regrId="Admin",
    modrNm="Admin",
    modrId="Admin"
)

# Example: Send branch user account information
response = branch_info.send_branch_user_account(branch_user_account_info)

insurance_info = BranchInsuranceInformation(
    isrccCd="ISRCC01",
    isrccNm="RSSB Insurance",
    isrcRt=20,
    useYn="Y",
    regrNm="Admin",
    regrId="Admin",
    modrNm="Admin",
    modrId="Admin"
)

# Example: Send branch insurance information
response = branch_info.send_branch_insurance_information(insurance_info)
```

### 7. Sales Information

```python
# Example Sales Transaction
# Create Receipt object
receipt = Receipt(
    custTin = "100110263",
    custMblNo = None,
    rptNo = 1,
    trdeNm = "",
    adrs = "",
    topMsg = "Shopwithus",
    btmMsg = "Welcome",
    prchrAcptcYn = "N"
)

# Create Item object
item = Item(
    itemSeq = 1,
    itemCd = "KE1NTXU0000001",
    itemClsCd = "5059690800",
    itemNm = "OutDoorUnit",
    bcd = None,
    pkgUnitCd = "NT",
    pkg = 1,
    qtyUnitCd = "U",
    qty = 1,
    prc = 200000,
    splyAmt = 200000,
    dcRt = 0,
    dcAmt = 0,
    isrccCd = None,
    isrccNm = None,
    isrcRt = None,
    isrcAmt = None,
    taxTyCd = "B",
    taxblAmt = 200000,
    taxAmt = 30508,
    totAmt = 200000
)

# Create Item 2 object
item2 = Item(
    itemSeq = 2,
    itemCd = "KE1NTXU0000002",
    itemClsCd = "5022110801",
    itemNm = "NetworkCable",
    bcd = None,
    pkgUnitCd = "NT",
    pkg = 1,
    qtyUnitCd = "U",
    qty = 1,
    prc = 50000,
    splyAmt = 50000,
    dcRt = 0,
    dcAmt = 0,
    isrccCd = None,
    isrccNm = None,
    isrcRt = None,
    isrcAmt = None,
    taxTyCd = "B",
    taxblAmt = 50000,
    taxAmt = 7627,
    totAmt = 50000
)

# Create Sales Transaction object
sales_transaction = SalesTransaction(
    trdInvcNo = 123,
    invcNo = 15,
    orgInvcNo = 0,
    custTin = "A123456789Z",
    custNm = "KRA",
    salesTyCd = "N",
    rcptTyCd = "S",
    pmtTyCd = "01",
    salesSttsCd = "02",
    cfmDt = "20210709120300",
    salesDt = "20210709",
    stockRlsDt = "20210709120300",
    cnclReqDt = None,
    cnclDt = None,
    rfdDt = None,
    rfdRsnCd = None,
    totItemCnt = 2,
    taxblAmtA = 0,
    taxblAmtB = 250000,
    taxblAmtC = 0,
    taxblAmtD = 0,
    taxblAmtE = 0,
    taxRtA = 0,
    taxRtB = 18,
    taxRtC = 0,
    taxRtD = 0,
    taxRtE = 0,
    taxAmtA = 0,
    taxAmtB = 94576,
    taxAmtC = 0,
    taxAmtD = 0,
    taxAmtE = 0,
    totTaxblAmt = 250000,
    totTaxAmt = 38135,
    totAmt = 250000,
    prchrAcptcYn = "N",
    remark = None,
    regrId = "11999",
    regrNm = "TestVSCU",
    modrId = "45678",
    modrNm = "TestVSCU",
    itemList = [item, item2],
    receipt = receipt
)


sales_management = SalesManagement(http_client, tin, bhf_id)

# # Example: Create sales transaction
create_sales_transaction_response = sales_management.send_sales_transaction_information(sales_transaction)
print(create_sales_transaction_response.json())
```

## Conclusion

This document provides a guide on using the ETIMS VSCU Wrapper to interact with the ETIMS system. Ensure to handle responses appropriately and replace placeholder data with actual values as per your integration needs.
