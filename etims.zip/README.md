# ETIMS VSCU Wrapper

The **ETIMS VSCU Wrapper** is a Python package designed to simplify interaction with the ETIMS VSCU (Virtual Supply Chain Utility) API. It provides a set of classes and methods to handle various operations such as data initialization, code retrieval, branch management, item information management, and more.

## Installation

You can install the **ETIMS VSCU Wrapper** package using pip. Navigate to the directory containing `setup.py` and run:

```bash
pip install requests
```

```bash
pip install .
```

## Usage

Here's a basic example demonstrating how to use the wrapper:

```python
# Import necessary classes from the package
from etims_vscu_wrapper.clients.http_client import HttpClient
from etims_vscu_wrapper.data.data_initialization import DataInitialization

# Define base URL and other required parameters
base_url = 'http://localhost:8088'
tin = 'P051238105V'
bhf_id = '07'
device_serial_no = 'DJV007'

# Create an instance of the HttpClient class
http_client = HttpClient(base_url)

# Create an instance of the DataInitialization class
data_init = DataInitialization(http_client, tin, bhf_id, device_serial_no)

# Call the initialize method
device_init_response = data_init.initialize()

# Handle the response as needed
print(device_init_response.status_code)
print(device_init_response.json())
```

## Documentation

For detailed documentation and usage examples, please refer to the [documentation](Doc.md).

## Contributing

Contributions are welcome! Please see our [contribution guidelines](link-to-your-contribution-guidelines) for details.

## License

This project is licensed under the MIT License - see the [LICENSE](link-to-your-license-file) file for details.

## Acknowledgments

- This package was inspired by the need to simplify interaction with the ETIMS VSCU API.
