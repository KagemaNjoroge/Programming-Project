from setuptools import setup, find_packages

setup(
    name='etims_vscu_wrapper',
    version='0.1',
    packages=find_packages(),
    author='DejavuTech',
    author_email='DejavuTech@email.com',
    description='A Python wrapper for ETIMS VSCU API',
    url='https://github.com/DejavuTechLTD/etims_vscu_wrapper.git',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)