import json
from etims_vscu_wrapper.clients.http_client import HttpClient
from etims_vscu_wrapper.core.VSCUProtocol.code_data import CodeData


base_url = "http://192.168.1.54:8088"
tin = "P051238105V"
bhf_id = "07"
device_serial_no = "DJV007"


http_client = HttpClient(base_url)

code_data = CodeData(http_client, tin, bhf_id)


print(code_data.get_pin_list(tin).json())
