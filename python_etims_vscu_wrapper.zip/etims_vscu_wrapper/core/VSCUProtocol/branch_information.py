from etims_vscu_wrapper.clients.http_client import HttpClientInterface
from etims_vscu_wrapper.data.post.branch_information import CustomerInformation, BranchUserAccount, BranchInsuranceInformation

class BranchInformation:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id):
        """
        Initializes the CustomerService.

        Args:
            http_client: An instance of the class responsible for making API requests.
            tin (str): The TIN (Taxpayer Identification Number).
            bhf_id (str): The branch ID.
        """
        self.http_client = http_client
        self.tin = tin
        self.bhf_id = bhf_id

    def send_customer_information(self, customer_info: CustomerInformation):
        """
        Sends customer information to the API.

        Args:
            customer_info (CustomerInformation): An instance of CustomerInformation.

        Returns:
            dict: The response from the API.

        Raises:
            ValueError: If the customer_info is not valid.
            Exception: If there is an error sending the request.
        """
        if not customer_info.is_valid():
            raise ValueError("Invalid customer information.")

        try:
            request_data = customer_info.__dict__
            request_data["tin"] = self.tin
            request_data["bhfId"] = self.bhf_id

            response = self.http_client.send_request(
                '/branches/saveBrancheCustomers', data=request_data)
            return response
        except Exception as e:
            raise Exception("Error sending request to API:", str(e))


    def send_branch_user_account(self, user_account_info: BranchUserAccount):
            """
            Sends branch user account information to the API.

            Args:
                user_account_info (BranchUserAccount): An instance of BranchUserAccount containing the user account information.

            Returns:
                dict: The response from the API.

            Raises:
                ValueError: If the user_account_info is not valid.
                Exception: If there is an error sending the request.
            """
            if not user_account_info.is_valid():
                raise ValueError("Invalid user account information.")

            try:
                request_data = user_account_info.__dict__
                request_data["tin"] = self.tin
                request_data["bhfId"] = self.bhf_id

                response = self.http_client.send_request(
                    '/branches/saveBrancheUsers', data=request_data)
                return response
            except Exception as e:
                raise Exception("Error sending request to API:", str(e))
            
    def send_branch_insurance_information(self, insurance_info: BranchInsuranceInformation):
        """
        Sends branch insurance information to the API.

        Args:
            insurance_info (BranchInsuranceInformation): An instance of BranchInsuranceInformation containing the insurance information.

        Returns:
            dict: The response from the API.

        Raises:
            ValueError: If the insurance_info is not valid.
            Exception: If there is an error sending the request.
        """
        if not insurance_info.is_valid():
            raise ValueError("Invalid insurance information.")

        try:
            request_data = insurance_info.__dict__
            request_data["tin"] = self.tin
            request_data["bhfId"] = self.bhf_id
            
            response = self.http_client.send_request(
                '/branches/saveBrancheInsurances', data=request_data)
            return response
        except Exception as e:
            raise Exception("Error sending request to API:", str(e))