from etims_vscu_wrapper.clients.http_client import HttpClientInterface

class ImportedItem:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id):
        self.api_request = http_client
        self.tin = tin
        self.bhf_id = bhf_id

    def get_imported_item_information(self, last_req_dt="20200101000000"):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            "lastReqDt": last_req_dt
        }
        response = self.api_request.send_request(
            '/imports/selectImportItems', data=request_data)
        return response

    def send_converted_imported_item_information(self, converted_imported_item_information):
        request_data = {
            "tin": self.tin,
            "bhfId": self.bhf_id,
            **converted_imported_item_information
        }
        response = self.api_request.send_request(
            '/imports/updateImportItems', data=request_data)
        return response
