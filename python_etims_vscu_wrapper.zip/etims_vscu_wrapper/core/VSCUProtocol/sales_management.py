import json
from etims_vscu_wrapper.clients.http_client import HttpClientInterface

class SalesManagement:
    def __init__(self, http_client: HttpClientInterface, tin, bhf_id):
        """
        Initializes the SalesManagement.

        Args:
            http_client: An instance of the class responsible for making API requests.
            tin (str): The TIN (Taxpayer Identification Number).
            bhf_id (str): The branch ID.
        """
        self.http_client = http_client
        self.tin = tin
        self.bhf_id = bhf_id

    def send_sales_transaction_information(self, sales_info):
        """
        Sends sales transaction information to the API.

        Args:
            sales_info (dict): A dictionary containing sales transaction information.

        Returns:
            dict: The response from the API.

        Raises:
            Exception: If there is an error sending the request.
        """
        if not sales_info.is_valid():
            raise ValueError("Invalid sales transaction information.")

        # Validate receipt
        if not sales_info.receipt.is_valid():
            raise ValueError("Receipt data is invalid")
        
        # Validate each item
        for item in sales_info.itemList:
            if not item.is_valid():
                raise ValueError("Item data is invalid")

        try:
            request_data = sales_info.__dict__
            request_data["tin"] = self.tin
            request_data["bhfId"] = self.bhf_id
            request_data["receipt"] = request_data["receipt"].__dict__
            itemList_dicts = []

            for item in request_data['itemList']:
                itemList_dicts.append(item.__dict__)

            request_data['itemList'] = itemList_dicts

            response = self.http_client.send_request(
                '/trnsSales/saveSales', data=request_data)
            return response
        except Exception as e:
            raise Exception("Error sending request to API:", str(e))
