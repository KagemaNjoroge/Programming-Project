from abc import ABC, abstractmethod
import requests
import json

class HttpClientInterface(ABC):
    @abstractmethod
    def send_request(self, path, method='POST', data=None):
        pass

class HttpClient(HttpClientInterface):
    def __init__(self, base_url):
        self.base_url = base_url

    def send_request(self, path, method='POST', data=None):
        url = self.base_url + path

        if method == 'POST':
            response = requests.post(url, json=data)
        elif method == 'GET':
            response = requests.get(url, params=data)
        else:
            raise ValueError(
                "Unsupported HTTP method. Supported methods are 'POST' and 'GET'.")

        return response