import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def validate_fields(expected_lengths, obj):
    """
    Validate fields of an object against expected lengths.

    Args:
        expected_lengths (dict): Dictionary containing field names as keys and expected lengths as values.
        obj: Object instance to validate.

    Returns:
        bool: True if all fields pass validation, False otherwise.
    """
    for field, length in expected_lengths.items():
        if not getattr(obj, field):
            continue  # Skip optional fields

        field_value = str(getattr(obj, field))  # Convert field value to string
        field_length = len(field_value)
        logger.info(f"Validating {field}: {field_value}")

        if field_length > length:
            logger.error(f"Validation failed for {field}: Length exceeds maximum allowed length of {length}")
            return False
        else:
            logger.info(f"{field} validation passed")
    return True
